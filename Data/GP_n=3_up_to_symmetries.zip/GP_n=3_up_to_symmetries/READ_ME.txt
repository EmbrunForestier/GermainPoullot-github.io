#- All code is meant to be used in Sage 9.x with x >= 1

This folder contains a "description" of the submodular cone SC4 for n = 4, that is the cone of deformations of the (standard) 3-dimensionnal permutahedron Pi4 (embeded in R^4).

This cone is {x ; < x | n(S,u,v) > \geq 0   for u, v \in S \subseteq [n]}.
SC4 has 4 lines (corresponding to the 4 trandlations of R^4) that we discarded to get a 11-dimensionnal cone with 24 facets and 37 rays.
Each element of this cone is a polytope (a deformation of Pi4, a.k.a generalized permutahedron), and each face of SC4 correspond to a familly of normally equivalent polytopes.

SC4 has 22 107 (unbounded) faces, its f-vector is:
(37, 356, 1596, 3985, 5980, 5560, 3212, 1128, 228, 24, 1)

As it would be impossible to handle, we don't illustrate each face: we quotient by the automorphism group of Pi4. This group has 48 = 2 * 4! elements: the "2" correspond to the central symmetry, while the "4!" correspond to the relabelling of the coordinates (i.e. Aut(Pi4) = { +- Mat(sigma) ; sigma in S_4 }). For each k, among the k-faces, we identify the faces that correspond to generalized permutahedra that are equivalent up to this group of symmetries. We call the classes of polytopes obtained by this quotient "generalized permutahedra up to symmetries".
SC4 has 703 combinatorially different (unbounded) faces, its f-vector "up to symmetry" is:
(7, 25, 64, 127, 174, 155, 97, 39, 12, 2, 1)
NB: The 11-dimensionnal face correspond to the permutahedron Pi4 (and all polytopes normally equivalent to it).

The folder is organized as follows:
* Sub-folders "k-face" for k in [1, ..., 11]
	Each sub-folder contains four kinds of files "j.txt", "j_fan_as_merging.txt", "j_unravel_symmetries.txt" and "j_data.txt" for j in [1, ..., number of symmetrically different k-faces of SC4], plus a file "faces_representative_vectors.txt"
* The file "face_lattice.txt"
* The file "About_the_data.txt"
* The file "Thoughts_on_the_computations.txt"
* The file "Observations_and_conjectures.txt"
* The file "Removahedra_not_GP_but_compact.txt" (see explanation in "Thoughts_on_the_computations.txt", section *Removahedron*)
(* This "READ_ME.txt" file)

Each file "j.txt" contains the vertices of a polytope: alltogether the files "k-face/j.txt" for fixed k and varying j is the collection of all generalized permutahedra (up to symmetries) whose deformation cone correspond to a k-face of SC4.
Each file "j_fan_as_merging.txt" contains a dict object (in Python format) that describes how to merge the maximal cones of the braid fan in order to obtain the normal fan of the generalized permutahedra described in "j.txt". See details below.
Each file "j_unravel_symmetries.txt" contains a list of elements x such that the generalized permutahedra described in "All_GP_n=4/k-face/x.txt" are equivalent to the one in "j.txt" up to symmetries (i.e. if you want to find all the generalized permutahedra equivalent to your favorite one up to symmetries, look in the files indicated here).
Each file "j_data.txt" contains information about the polytope described in "j.txt": details in "About_the_data.txt". This is typically the thing you want to read !

Each file "faces_representative_vectors.txt" contains a list of vectors (one per line), such that the j-th line is the submodular function associated to the polytope described in "j.txt". In other words, this vector gives the constant for the facet description of the polytope in "j.txt": it is its height vector. See details below.

The file "face_lattice.txt" contains the "face lattice of SC4 up to symmetries", that is the poset obtained by taking the face lattice of SC4 and contacting the equivalence classes induced byt the symmetries (of Pi4). The element of the lattice labelled (k, j) correspond to the polytope (whose vertices are) stored in "k-face/j.txt".
Be careful! In "face_lattice.txt", the element (k, j) is smaller than (k', j') when *there exists* a couple of deformations (Q, P) where Q is a deformation of P, and Q is equivalent up to symmetries to the polytope in "k-face/j.txt", and P is equivalent up to symmetries to the polytope in "k'-face/j'.txt" (not when *all* couples of such deformations are comparable). But, if (k, j) is smaller than (k', j') then it is true that for any P equivalent to "k'-face/j'.txt", there exists a Q equivalent to "k-face/j.txt" such that Q is a deformation of P (think about it for a minute : quotienting byt symmetries keep this property).

The file "Thoughts_on_the_computations.txt" contains the discussion of numerous functions I've coded for this project: it shall be read by anyone that want to use the project without starting from scratch! Although the file is long, functions are clean and readable (hopefully), but largely non optimal.

The file "Observations_and_conjectures.txt" contains very brief paragraphs discussing some examples, properties, etc, that I've wonder about or found interesting (plus some additionnal remarks "Bad thing" that need to be read as a gentle raillery and not taken too seriously ^^).


*Some details*
To get a polytope as a Polyhedron object in Sage, you can open a file "k-face/j.txt" (for instance with my_file = open(address_of_my_file, 'r') ), and then input "Polyhedron(vertices = [eval(li) for li in fi.readlines()])". Don't forget to close your file!
Let's see a more concrete example: suppose you want to get all the generalized permutahedra (up to symmetry) in a vast list. You would prefer a dict object actually. To get a dictionnary PP where PP[(k, j)] is the polytope described in the file "k-face/j.txt", here is a code (you need to precise where you saved the folder):
"""
Folder_address = "where I saved the folder"  # "/home/sage/Downloads/" for me, ends with /

PP = dict()

n = 4
lens = {1: 7, 2: 25, 3: 64, 4: 127, 5: 174, 6: 155, 7: 97, 8: 39, 9: 12, 10: 2, 11: 1}  # lens[k] is the number of files to look for in the folder "k-face"

for k in range(1, 2^n - n):
    for j in range(1, lens[k]+1):
        name = Folder_address + "GP_n=H_up_to_symmetries/K-face/J.txt".replace("H",str(n)).replace("K",str(k)).replace('J',str(j))
        fi = open(name, 'r')
        PP[(k, j)] = Polyhedron(vertices = [eval(li) for li in fi.readlines()])
        fi.close()
print(len(PP))  # Shall be: 703
"""


To get the face lattice (up to symmetries) as a Poset FL:
"""
Folder_address = "where I saved the folder"  # "/home/sage/Downloads/" for me, ends with /

n = 4
name = Folder_address + "GP_n=H_up_to_symmetries/face_lattice.txt".replace("H",str(n))
fi = open(name, 'r')
FL = DiGraph( [eval(e) for e in fi.readlines()] )
fi.close()

FL = Poset(FL)
print(FL)  # Shall be: Finite poset containing 703 elements
"""


*About fan as merging*
The normal fan of a generalized permutahedron is a coarsening of the braid fan (which is the normal fan of the standard permutahedron).
To describe this coarsening, we have chosen the following convention: a dictionnary D whose keys are vertices and values are lists of permutations.
Fix a generalized permutahedron P, with vertices v_1, ..., v_r. The describe the normal fan, it is enough to give the normal cones of the vertices.
To have such a cone as a coarsening of the braid fan, remember that the (maximal) cones of the braid fan are associated to permutations.
Thus, D[v_1] will be the list of all permutations sigma such that the normal cone of v_1 in P contains the cone associated to sigma (in the braid fan).
In other words, for all sigma in D[v_1], v_1 maximizes the scalar product against the vector (sigma(1), ..., sigma(n)), among the vertices of P.
Usefull code:
"""
name = Folder_address + "GP_n=H_up_to_symmetries/K-face/L_fan_as_merging.txt".replace("H", str(n)).replace("K", str(k)).replace("L", str(l))
fi = open(name, 'r')
di = eval(fi.readline())
di = {x : [Permutation(p) for p in di[x]] for x in di}
fi.close()
"""

*About faces_representative_vectors*
The j-th line correspond to "k-face/j.txt". Pick a line, and read it as a vector v. Here is what you can do with v:
1. How to read the submodular function ?
The submodular function f *is* the vector v in the following sense : for a subset A of {1, ..., n}, tha value f(A) is written is the coordinate of v in position int(A) = sum_{i in A} 2^i  (this is just the binary writing of A).
2. How to get the polytope P described in "j.txt" ?
The height vector of P is v, that is to say : P = { x ; < g_A | x >  >= v[int(A)] } where g_A is the g-vector associated to A, i.e. the projection of sum_{i in A} e_i onto the plane { x ; sum_i x_i = 0 }.

